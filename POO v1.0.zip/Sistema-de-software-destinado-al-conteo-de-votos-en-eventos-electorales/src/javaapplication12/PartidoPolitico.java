/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication12;

// PartidoPolitico.java
public class PartidoPolitico {
    private String nombre;
    private String sigla;
    private String logo; // Podría ser una ruta a la imagen o el nombre del archivo
    private String reprelegal;

    public PartidoPolitico(String nombre, String sigla, String logo, String reprelegal) {
        this.nombre = nombre;
        this.sigla = sigla;
        this.logo = logo;
        this.reprelegal = reprelegal;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public String getReprelegal() {
        return reprelegal;
    }

    public void setReprelegal(String reprelegal) {
        this.reprelegal = reprelegal;
    }

    // Métodos para registrar, modificar, eliminar partidos políticos
    public void registrar() {
        System.out.println("Registrando partido político: " + nombre + " (" + sigla + ")");
    }

    public void modificar() {
        System.out.println("Modificando partido político: " + nombre);
    }

    public void eliminar() {
        System.out.println("Eliminando partido político: " + nombre);
    }
}

