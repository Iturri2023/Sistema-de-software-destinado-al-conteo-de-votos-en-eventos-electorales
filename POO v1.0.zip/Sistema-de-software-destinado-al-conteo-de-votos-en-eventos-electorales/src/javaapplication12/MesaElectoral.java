/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication12;

// MesaElectoral.java
public class MesaElectoral implements Registro {
    private String idMesa;
    private String ubicacion;
    private MiembroDeMesa[] miembrosMesa; // Usando arreglo fijo para miembros de mesa
    private int numMiembrosActual; // Para controlar el número de miembros asignados
    private static final int MAX_MIEMBROS = 3; // Ejemplo: 1 presidente, 1 secretario, 1 vocal
    
    public MesaElectoral(String idMesa, String ubicacion) {
        this.idMesa = idMesa;
        this.ubicacion = ubicacion;
        this.miembrosMesa = new MiembroDeMesa[MAX_MIEMBROS];
        this.numMiembrosActual = 0;
    }

    public String getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(String idMesa) {
        this.idMesa = idMesa;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public MiembroDeMesa[] getMiembrosMesa() {
        return miembrosMesa;
    }

    // Asignar miembros a la mesa
    public void asignarMiembro(MiembroDeMesa miembro) {
        if (numMiembrosActual < MAX_MIEMBROS) {
            miembrosMesa[numMiembrosActual] = miembro;
            numMiembrosActual++;
            System.out.println("Miembro " + miembro.getNombre() + " asignado a mesa " + idMesa);
        } else {
            System.out.println("La mesa " + idMesa + " ya tiene el máximo de miembros.");
        }
    }

    @Override
    public void registrar() {
        System.out.println("Registrando mesa electoral: " + idMesa + ", Ubicación: " + ubicacion);
    }

    @Override
    public void modificar() {
        System.out.println("Modificando mesa electoral: " + idMesa);
    }

    @Override
    public void eliminar() {
        System.out.println("Eliminando mesa electoral: " + idMesa);
    }
}
