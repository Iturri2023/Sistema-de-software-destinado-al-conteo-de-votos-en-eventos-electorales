package javaapplication12;

public interface Registro {

    public void registrar();
    public void modificar();
    public void eliminar();


}
