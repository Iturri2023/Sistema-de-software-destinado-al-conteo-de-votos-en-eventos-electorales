/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication12;
import java.util.Scanner;
/**
 *
 * @author TEC GAMER
 */
public class SISTEMA {

    public static void main(String[] args) {
        
        Scanner scn = new Scanner(System.in);
        Operador op1 = new Operador("host", "123");

        System.out.println("Ingrese el nombre de usuario del operador:");
        String usuario = scn.nextLine();

        System.out.println("Ingrese la contraseña del operador:");
        String contrasena = scn.nextLine(); 
        int contador = 0;

        while (contador < 2){
            if (op1.autenticar(usuario, contrasena)) { // 
            System.out.println("\nOperador autenticado exitosamente.");
            break;
        } else {
            contador++;
            System.out.println("\nFallo en la autenticación del operador.");
            
            System.out.println("Ingrese el nombre de usuario del operador:");
            usuario = scn.nextLine();
            System.out.println("Ingrese la contraseña del operador: \n");
            contrasena = scn.nextLine(); 
            if (contador == 2) {
                System.out.println("Número máximo de intentos alcanzado. Saliendo del sistema.");
                return; 
        } 
        }
    }
          
        PartidoPolitico pp1 = new PartidoPolitico("Partido Unidad Nacional", "PUN", "logo_pun.png", "Juan Perez");
        pp1.registrar(); // 

        // 2. Crear candidatos
        Candidato c1 = new Candidato("Maria", "Gonzales", "12345678", pp1);
        c1.registrar(); // 
        Candidato c2 = new Candidato("Carlos", "Ramirez", "87654321", pp1);
        c2.registrar();

        // 3. Crear una elección
        Eleccion eleccionNacional2025 = new Eleccion("ELECC001", "2025-10-26", "nacional");
        eleccionNacional2025.registrar(); // 

        // 4. Asignar candidatos a la elección
        eleccionNacional2025.agregarCandidato(c1);
        eleccionNacional2025.agregarCandidato(c2);

        // 5. Crear miembros de mesa
        MiembroDeMesa mdm1 = new MiembroDeMesa("Ana", "Lopez", "presidente");
        mdm1.registrar(); // 
        MiembroDeMesa mdm2 = new MiembroDeMesa("Pedro", "Gomez", "secretario");

        // 6. Crear una mesa electoral y asignar miembros
        MesaElectoral mesa101 = new MesaElectoral("MESA101", "Escuela #5");
        mesa101.registrar(); // 
        mesa101.asignarMiembro(mdm1); // 
        mesa101.asignarMiembro(mdm2);
        eleccionNacional2025.agregarMesaElectoral(mesa101);

        // 7. Registrar un acta de votos para la mesa
        // Se asume que los candidatos en la eleccion estan en un orden conocido para 'resultadosPorCandidato'
        RegistroDeActas actaMesa101 = new RegistroDeActas("ACTA101", "10/10/10" ,"20:20","lima","01" );
        actaMesa101.agregarMiembroPresente(mdm1); 
        actaMesa101.agregarMiembroPresente(mdm2);

        actaMesa101.registrarVotos(0, 100); // 100 votos para el candidato 0 (Maria Gonzales) 
        actaMesa101.registrarVotos(1, 80);  // 80 votos para el candidato 1 (Carlos Ramirez)
        actaMesa101.setVotosEnBlanco(5);
        actaMesa101.setVotosNulos(5); 
        actaMesa101.setObservaciones("Ninguna");
        actaMesa101.setFirmas(true);
        actaMesa101.setSelloOficial(true);

        

        System.out.println("\nResumen del Acta " + actaMesa101.getNumeroActaUnico());
        System.out.println("Votos para candidato 0: " + actaMesa101.getResultadosPorCandidato()[0]);
        System.out.println("Votos para candidato 1: " + actaMesa101.getResultadosPorCandidato()[1]);
        System.out.println("Votos en blanco: " + actaMesa101.getVotosEnBlanco());
        System.out.println("Votos nulos: " + actaMesa101.getVotosNulos());

    
    }
    }
    
