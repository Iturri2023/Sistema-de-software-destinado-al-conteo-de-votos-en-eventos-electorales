/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication12;


public class Eleccion implements Registro { 
    private String id;
    private String fecha; // Formato String "YYYY-MM-DD"
    private String tipoEleccion; // "municipal", "nacional", "referendum"
    private Candidato[] candidatosAsociados; // Arreglo para candidatos asociados
    private int numCandidatosActual;
    private MesaElectoral[] mesasElectorales; // Arreglo para mesas electorales
    private int numMesasActual;
    private static final int MAX_CANDIDATOS = 50; // Ejemplo de tamaño máximo
    private static final int MAX_MESAS = 100; // Ejemplo de tamaño máximo

    public Eleccion(String id, String fecha, String tipoEleccion) {
        this.id = id;
        this.fecha = fecha;
        this.tipoEleccion = tipoEleccion;
        this.candidatosAsociados = new Candidato[MAX_CANDIDATOS];
        this.numCandidatosActual = 0;
        this.mesasElectorales = new MesaElectoral[MAX_MESAS];
        this.numMesasActual = 0;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getTipoEleccion() {
        return tipoEleccion;
    }

    public void setTipoEleccion(String tipoEleccion) {
        this.tipoEleccion = tipoEleccion;
    }

    // Métodos para gestionar candidatos y mesas asociadas
    public void agregarCandidato(Candidato candidato) {
        if (numCandidatosActual < MAX_CANDIDATOS) {
            candidatosAsociados[numCandidatosActual] = candidato;
            numCandidatosActual++;
            System.out.println("Candidato " + candidato.getNombre() + " agregado a elección " + id);
        } else {
            System.out.println("Límite de candidatos alcanzado para la elección " + id);
        }
    }

    public void agregarMesaElectoral(MesaElectoral mesa) {
        if (numMesasActual < MAX_MESAS) {
            mesasElectorales[numMesasActual] = mesa;
            numMesasActual++;
            System.out.println("Mesa " + mesa.getIdMesa() + " agregada a elección " + id);
        } else {
            System.out.println("Límite de mesas electorales alcanzado para la elección " + id);
        }
    }

    @Override
    public void registrar() { // En el UML aparece como "crear()"
        System.out.println("Creando elección: " + tipoEleccion + " (" + fecha + ")");
    }

    @Override
    public void modificar() {
        System.out.println("Modificando elección: " + id);
    }

    @Override
    public void eliminar() {
        System.out.println("Eliminando elección: " + id);
    }
}
