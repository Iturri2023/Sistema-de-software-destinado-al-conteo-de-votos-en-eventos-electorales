/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication12;

/**
 *
 * @author TEC GAMER
 */
// MiembroDeMesa.java
public class MiembroDeMesa extends Persona {
    private String tipoMiembro; // "presidente", "secretario", "vocal"

    public MiembroDeMesa(String nombre, String apellido, String tipoMiembro) {
        super(nombre, apellido);
        this.tipoMiembro = tipoMiembro;
    }

    public String getTipoMiembro() {
        return tipoMiembro;
    }

    public void setTipoMiembro(String tipoMiembro) {
        this.tipoMiembro = tipoMiembro;
    }

    // Métodos para registrar, modificar, eliminar miembros de mesa
    public void registrar() {
        System.out.println("Registrando miembro de mesa: " + nombre + " " + apellido + ", Tipo: " + tipoMiembro);
    }

    public void modificar() {
        System.out.println("Modificando miembro de mesa: " + nombre + " " + apellido);
    }

    public void eliminar() {
        System.out.println("Eliminando miembro de mesa: " + nombre + " " + apellido);
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Miembro de Mesa: " + nombre + " " + apellido + ", Rol: " + tipoMiembro);
    }
}
