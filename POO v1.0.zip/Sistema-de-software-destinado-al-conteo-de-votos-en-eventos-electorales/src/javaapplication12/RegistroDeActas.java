
package javaapplication12;

// RegistroDeActas.java
public class RegistroDeActas {
    private String tituloDocumento;
    private String fecha;
    private String hora; // Formato String "HH:MM"
    private String ubicacion;
    private String idMesa;
    private MiembroDeMesa[] miembrosMesaPresentes;
    private int numMiembrosPresentes;
    private int numVotantesRegistrados;
    private int numVotantesEfectivos;
    private int[] resultadosPorCandidato;
    private int votosEnBlanco;
    private int votosNulos;
    private String observaciones;
    private boolean firmas;
    private boolean selloOficial;
    private String numeroActaUnico;

    public RegistroDeActas(String tituloDocumento, String fecha, String hora, String ubicacion, String idMesa) {
        this.tituloDocumento = tituloDocumento;
        this.fecha = fecha;
        this.hora = hora;
        this.ubicacion = ubicacion;
        this.idMesa = idMesa;
        this.miembrosMesaPresentes = new MiembroDeMesa[3]; // Asumiendo 3 miembros por mesa
        this.numMiembrosPresentes = 0;
        this.numVotantesRegistrados = 0;
        this.numVotantesEfectivos = 0;
        this.resultadosPorCandidato = new int[2]; // Asumiendo 2 candidatos
        this.votosEnBlanco = 0;
        this.votosNulos = 0;
        this.observaciones = "";
        this.firmas = false;
        this.selloOficial = false;
        this.numeroActaUnico = generarNumeroActaUnico();
    }

    public String getTituloDocumento() {
        return tituloDocumento;
    }

    public void setTituloDocumento(String tituloDocumento) {
        this.tituloDocumento = tituloDocumento;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(String idMesa) {
        this.idMesa = idMesa;
    }

    public MiembroDeMesa[] getMiembrosMesaPresentes() {
        return miembrosMesaPresentes;
    }

    public void setMiembrosMesaPresentes(MiembroDeMesa[] miembrosMesaPresentes) {
        this.miembrosMesaPresentes = miembrosMesaPresentes;
    }

    public int getNumMiembrosPresentes() {
        return numMiembrosPresentes;
    }

    public void setNumMiembrosPresentes(int numMiembrosPresentes) {
        this.numMiembrosPresentes = numMiembrosPresentes;
    }

    public int getNumVotantesRegistrados() {
        return numVotantesRegistrados;
    }

    public void setNumVotantesRegistrados(int numVotantesRegistrados) {
        this.numVotantesRegistrados = numVotantesRegistrados;
    }

    public int getNumVotantesEfectivos() {
        return numVotantesEfectivos;
    }

    public void setNumVotantesEfectivos(int numVotantesEfectivos) {
        this.numVotantesEfectivos = numVotantesEfectivos;
    }

    public int[] getResultadosPorCandidato() {
        return resultadosPorCandidato;
    }

    public void setResultadosPorCandidato(int[] resultadosPorCandidato) {
        this.resultadosPorCandidato = resultadosPorCandidato;
    }

    public int getVotosEnBlanco() {
        return votosEnBlanco;
    }

    public void setVotosEnBlanco(int votosEnBlanco) {
        this.votosEnBlanco = votosEnBlanco;
    }

    public int getVotosNulos() {
        return votosNulos;
    }

    public void setVotosNulos(int votosNulos) {
        this.votosNulos = votosNulos;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public boolean isFirmas() {
        return firmas;
    }

    public void setFirmas(boolean firmas) {
        this.firmas = firmas;
    }

    public boolean isSelloOficial() {
        return selloOficial;
    }

    public void setSelloOficial(boolean selloOficial) {
        this.selloOficial = selloOficial;
    }

    public String getNumeroActaUnico() {
        return numeroActaUnico;
    }

    public void setNumeroActaUnico(String numeroActaUnico) {
        this.numeroActaUnico = numeroActaUnico;
    }

    public void agregarMiembroPresente(MiembroDeMesa miembro) {
        if (numMiembrosPresentes < 3) {
            miembrosMesaPresentes[numMiembrosPresentes] = miembro;
            numMiembrosPresentes++;
        } else {
            System.out.println("Ya se han registrado los miembros firmantes de esta acta.");
        }
    }

    public void registrarVotos(int indiceCandidato, int votos) {
        if (indiceCandidato >= 0 && indiceCandidato < resultadosPorCandidato.length) {
            resultadosPorCandidato[indiceCandidato] += votos;
            System.out.println("Votos registrados para el candidato en el índice " + indiceCandidato + ": " + votos);
        } else {
            System.out.println("Índice de candidato inválido.");
        }
    }

    public void corregirErrores() {
        System.out.println("Corrigiendo errores en el registro de acta " + numeroActaUnico);
        // Lógica para permitir la corrección de datos
    }

    public void registrarVotosPreferenciales() {
        System.out.println("Registrando votos preferenciales en acta " + numeroActaUnico);
        // Lógica para registrar votos preferenciales por candidato
    }

    // Método para generar un número de acta único (simplificado)
    private String generarNumeroActaUnico() {
        // retorne un string "ACTA-" + un número único que ingresara el operador
        return "ACTA-" + System.currentTimeMillis();
    }

}
