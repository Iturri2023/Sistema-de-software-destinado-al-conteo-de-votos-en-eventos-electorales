/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication12;

// Candidato.java
public class Candidato extends Persona {
    private String dni;
    private PartidoPolitico partidoPolitico; // Relación de asociación con PartidoPolitico

    public Candidato(String nombre, String apellido, String dni, PartidoPolitico partidoPolitico) {
        super(nombre, apellido);
        this.dni = dni;
        this.partidoPolitico = partidoPolitico;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public PartidoPolitico getPartidoPolitico() {
        return partidoPolitico;
    }

    public void setPartidoPolitico(PartidoPolitico partidoPolitico) {
        this.partidoPolitico = partidoPolitico;
    }

    // Métodos para registrar, modificar, eliminar candidatos (según el UML)
    public void registrar() {
        System.out.println("Registrando candidato: " + nombre + " " + apellido + " DNI: " + dni + " del partido " + partidoPolitico.getNombre());
    }

    public void modificar() {
        System.out.println("Modificando candidato: " + nombre + " " + apellido);
    }

    public void eliminar() {
        System.out.println("Eliminando candidato: " + nombre + " " + apellido);
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Candidato: " + nombre + " " + apellido + ", DNI: " + dni + ", Partido: " + partidoPolitico.getNombre());
    }
}




