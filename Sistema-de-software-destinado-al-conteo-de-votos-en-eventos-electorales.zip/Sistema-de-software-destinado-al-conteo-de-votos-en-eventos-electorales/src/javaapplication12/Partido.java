/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication12;

public class Partido {
    private String nombre;
    private String sigla;
    private String representanteLegal;

    //CONSTRUCTORES

    public Partido(String nombre, String sigla, String representanteLegal) {
        this.nombre = nombre;
        this.sigla = sigla;
        this.representanteLegal = representanteLegal;
    }
    
    //GETTERS AND SETTERS

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getRepresentanteLegal() {
        return representanteLegal;
    }

    public void setRepresentanteLegal(String representanteLegal) {
        this.representanteLegal = representanteLegal;
    }
    
    //METODO
    
    public void mostrarInformacion() {
        System.out.println("Partido: " + nombre + " (" + sigla + ")");
    }

}

