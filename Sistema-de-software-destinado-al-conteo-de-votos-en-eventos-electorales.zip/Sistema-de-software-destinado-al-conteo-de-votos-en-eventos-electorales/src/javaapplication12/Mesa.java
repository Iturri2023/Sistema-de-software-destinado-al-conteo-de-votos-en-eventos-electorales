/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication12;

public class Mesa {

    private String id;
    private MiembroMesa presidente;
    private MiembroMesa secretario;
    private MiembroMesa vocal;
    
    //CONSTRUCTORES

    public Mesa(String id, MiembroMesa presidente, MiembroMesa secretario, MiembroMesa vocal) {
        this.id = id;

    }
    
    //GETTERS AND SETTERS

    public String getId() {
        return id;
    }

    public MiembroMesa getPresidente() {
        return presidente;
    }

    public void setPresidente(MiembroMesa presidente) {
        this.presidente = presidente;
    }

    public MiembroMesa getSecretario() {
        return secretario;
    }

    public void setSecretario(MiembroMesa secretario) {
        this.secretario = secretario;
    }

    public MiembroMesa getVocal() {
        return vocal;
    }

    public void setVocal(MiembroMesa vocal) {
        this.vocal = vocal;
    }
    
    //METODO
    
        public void mostrarInformacion() {
        System.out.println("Mesa #" + id);
    }
    
}
