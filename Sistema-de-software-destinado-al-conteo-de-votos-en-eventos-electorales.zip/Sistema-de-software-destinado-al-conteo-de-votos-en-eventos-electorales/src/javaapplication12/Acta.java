/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication12;

public class Acta {
    
    private String numeroActa;
    private String fecha;
    private String hora;
    private String lugar;
    private String mesaId;

    //CONSTRUCTORES

    public Acta(String numeroActa, String fecha, String hora, String lugar, String mesaId) {
        this.numeroActa = numeroActa;
        this.fecha = fecha;
        this.hora = hora;
        this.lugar = lugar;
        this.mesaId = mesaId;
    }
    
    //GETTERS 

    public String getNumeroActa() {
        return numeroActa;
    }

    public String getFecha() {
        return fecha;
    }

    public String getHora() {
        return hora;
    }

    public String getLugar() {
        return lugar;
    }

    public String getMesaId() {
        return mesaId;
    }
    
    //METODO
    
    public void mostrarInformacion() {
        System.out.println("Acta #" + numeroActa + " - Mesa: " + mesaId);
    }
    


}
