/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication12;

public class Eleccion {
    private String id;
    private String fecha;
    private String tipo; // municipal, nacional, referéndum    

    //CONSTRUCTORES
    
    public Eleccion(String id, String fecha, String tipo) {
        this.id = id;
        this.fecha = fecha;
        this.tipo = tipo;
    }

    //GETTERS AND SETTERS
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    //METODO
    public void mostrarInformacion() {
        System.out.println("Elección: " + tipo + " - Fecha: " + fecha);
    }

}
