/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication12;

public class Candidato {
    private String dni;
    private String nombres;
    private String apellidos;
    private Partido partido;

    //CONSTRUCTORES

    public Candidato(String dni, String nombres, String apellidos, Partido partido) {
        this.dni = dni;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.partido = partido;
    }
    
    //GETTERS Y SETTERS

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Partido getPartido() {
        return partido;
    }

    public void setPartido(Partido partido) {
        this.partido = partido;
    }
    
    //METODO
    
    public void mostrarInformacion() {
        System.out.println("Candidato: " + nombres + " " + apellidos + " - Partido: " + partido.getNombre());
    }





}




