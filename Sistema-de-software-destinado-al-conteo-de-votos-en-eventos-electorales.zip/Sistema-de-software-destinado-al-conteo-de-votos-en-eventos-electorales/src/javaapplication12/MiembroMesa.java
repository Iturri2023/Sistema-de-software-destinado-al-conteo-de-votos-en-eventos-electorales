/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication12;

/**
 *
 * @author TEC GAMER
 */
public class MiembroMesa {
    private String nombres;
    private String apellidos;
    private String rol; // presidente, secretario, vocal

    //CONSTRUCTORES

    public MiembroMesa(String nombres, String apellidos, String rol) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.rol = rol;
    }

    public String getNombres() {
        return nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getRol() {
        return rol;
    }
    
    //METODO 
    

    public void mostrarInformacion() {
        System.out.println(rol + ": " + nombres + " " + apellidos);
    }

}
